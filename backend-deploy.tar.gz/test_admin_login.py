#!/usr/bin/env python3
"""
Test script for admin login debugging
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database.connection import get_db
from models.user import User, UserRole
from services.auth import authenticate_user, create_access_token, create_refresh_token
from schemas.user import UserResponse
from datetime import timedelta
from core.config import settings

def test_admin_login():
    """Test admin login step by step"""
    try:
        print("=== Admin Login Test ===")
        
        # Step 1: Get database connection
        db = next(get_db())
        print("✓ Database connection established")
        
        # Step 2: Find admin user
        admin_user = db.query(User).filter(User.email == 'admin@izishop.com').first()
        if not admin_user:
            print("✗ Admin user not found")
            return
        print(f"✓ Admin user found: {admin_user.email}")
        print(f"  - Role: {admin_user.role}")
        print(f"  - Active: {admin_user.is_active}")
        
        # Step 3: Test authentication
        user = authenticate_user(db, 'admin@izishop.com', 'Admin123!')
        if not user:
            print("✗ Authentication failed")
            return
        print("✓ Authentication successful")
        
        # Step 4: Test admin access code
        admin_code = 'gyBqgFc1PJWAbvESHf5LKHOYOn5GgNiitFskl8lEpznJbpCxFUvwXAc-5eXvB--Q'
        if admin_code != settings.ADMIN_ACCESS_CODE:
            print("✗ Admin access code mismatch")
            return
        print("✓ Admin access code verified")
        
        # Step 5: Test UserResponse creation
        try:
            user_response = UserResponse.from_orm(user)
            print("✓ UserResponse created successfully")
            print(f"  - User ID: {user_response.id}")
            print(f"  - Email: {user_response.email}")
            print(f"  - Role: {user_response.role}")
        except Exception as e:
            print(f"✗ UserResponse creation failed: {e}")
            return
        
        # Step 6: Test token creation
        try:
            access_token = create_access_token(
                data={"sub": user.email, "user_id": str(user.id)},
                expires_delta=timedelta(minutes=30)
            )
            refresh_token = create_refresh_token(
                data={"sub": user.email, "user_id": str(user.id)}
            )
            print("✓ Tokens created successfully")
            print(f"  - Access token length: {len(access_token)}")
            print(f"  - Refresh token length: {len(refresh_token)}")
        except Exception as e:
            print(f"✗ Token creation failed: {e}")
            return
        
        print("\n=== All tests passed! Admin login should work ===")
        
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if 'db' in locals():
            db.close()

if __name__ == "__main__":
    test_admin_login()
