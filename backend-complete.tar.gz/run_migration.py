#!/usr/bin/env python3
"""
Script to run the enhanced order tracking fields migration
"""

import sqlite3
import os

def run_migration():
    """Run the enhanced order tracking fields migration"""
    db_path = "izishop.db"
    migration_path = "migrations/add_enhanced_order_tracking_fields.sql"

    if not os.path.exists(db_path):
        print(f"Database file {db_path} not found")
        return

    if not os.path.exists(migration_path):
        print(f"Migration file {migration_path} not found")
        return

    try:
        # Read migration SQL
        with open(migration_path, 'r') as f:
            migration_sql = f.read()

        # Execute migration
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Split and execute each statement
        statements = migration_sql.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement and not statement.startswith('--'):
                try:
                    cursor.execute(statement)
                    print(f"Executed: {statement[:50]}...")
                except sqlite3.Error as e:
                    if "duplicate column name" in str(e).lower():
                        print(f"Column already exists (skipping): {statement[:50]}...")
                    else:
                        print(f"Error executing: {statement[:50]}... Error: {e}")

        conn.commit()
        conn.close()

        print("Migration completed successfully!")

    except Exception as e:
        print(f"Error running migration: {e}")

if __name__ == "__main__":
    run_migration()