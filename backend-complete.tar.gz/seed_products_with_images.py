#!/usr/bin/env python3
"""Seed products with sample images for testing"""

import json
from sqlalchemy.orm import Session
from database.connection import get_db_session
from models.product import Product
from models.user import User
import uuid

def seed_products_with_images():
    """Add sample products with placeholder images"""
    
    # Sample product data with placeholder images
    sample_products = [
        {
            "name": "iPhone 15 Pro Max",
            "description": "Latest Apple iPhone with advanced camera system",
            "price": 850000,
            "stock_quantity": 25,
            "image_urls": [
                "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400",
                "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400"
            ]
        },
        {
            "name": "Samsung Galaxy S24 Ultra",
            "description": "Premium Android smartphone with S-Pen",
            "price": 750000,
            "stock_quantity": 15,
            "image_urls": [
                "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400",
                "https://images.unsplash.com/photo-1574944985070-8f3ebc6b2290?w=400"
            ]
        },
        {
            "name": "MacBook Pro 14-inch",
            "description": "Apple MacBook Pro with M3 Pro chip",
            "price": 1200000,
            "stock_quantity": 8,
            "image_urls": [
                "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400",
                "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400"
            ]
        },
        {
            "name": "Nike Air Max 270",
            "description": "Comfortable running shoes with air cushioning",
            "price": 85000,
            "stock_quantity": 50,
            "image_urls": [
                "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400",
                "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400"
            ]
        },
        {
            "name": "Sony WH-1000XM5 Headphones", 
            "description": "Premium noise-canceling wireless headphones",
            "price": 185000,
            "stock_quantity": 30,
            "image_urls": [
                "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
                "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400"
            ]
        },
        {
            "name": "Dell XPS 13 Laptop",
            "description": "Ultra-thin laptop with Intel i7 processor", 
            "price": 950000,
            "stock_quantity": 12,
            "image_urls": [
                "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
                "https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=400"
            ]
        },
        {
            "name": "Canon EOS R5 Camera",
            "description": "Professional mirrorless camera with 45MP sensor",
            "price": 2200000,
            "stock_quantity": 5,
            "image_urls": [
                "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
                "https://images.unsplash.com/photo-1520637836862-4d197d17c15a?w=400"
            ]
        },
        {
            "name": "Apple Watch Series 9",
            "description": "Advanced smartwatch with health monitoring",
            "price": 285000,
            "stock_quantity": 40,
            "image_urls": [
                "https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=400",
                "https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400"
            ]
        }
    ]
    
    db = get_db_session()
    
    try:
        # Get the first user to assign as seller
        first_user = db.query(User).first()
        if not first_user:
            print("No users found in database. Please register a user first.")
            return
        
        print(f"Adding products for user: {first_user.email}")
        
        # Add products with images
        for product_data in sample_products:
            # Convert image URLs list to JSON string
            image_urls_json = json.dumps(product_data["image_urls"])
            
            product = Product(
                id=str(uuid.uuid4()),
                seller_id=first_user.id,
                name=product_data["name"],
                description=product_data["description"], 
                price=product_data["price"],
                stock_quantity=product_data["stock_quantity"],
                image_urls=image_urls_json,
                is_active=True
            )
            
            db.add(product)
            print(f"Added: {product.name}")
        
        db.commit()
        print(f"\nSuccessfully added {len(sample_products)} products with images!")
        
        # Verify the data
        products = db.query(Product).filter(Product.image_urls.isnot(None)).all()
        print(f"Total products with images in database: {len(products)}")
        
    except Exception as e:
        db.rollback()
        print(f"Error seeding products: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    seed_products_with_images()