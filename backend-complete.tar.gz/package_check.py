# Simple test to check what's working
try:
    import fastapi
    print("FastAPI imported successfully")
except Exception as e:
    print(f"FastAPI import failed: {e}")

try:
    import sqlalchemy
    print("SQLAlchemy imported successfully")
except Exception as e:
    print(f"SQLAlchemy import failed: {e}")

try:
    import pydantic
    print("Pydantic imported successfully")
except Exception as e:
    print(f"Pydantic import failed: {e}")

print("Python version check:")
import sys
print(f"Python version: {sys.version}")