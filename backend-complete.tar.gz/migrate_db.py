#!/usr/bin/env python3
"""
Database Migration: SQLite to PostgreSQL
Migrates Izishop database with data validation
"""

import os
import sys
import sqlite3
import psycopg2
import logging
from datetime import datetime

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.security_config import get_security_settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseMigrator:
    def __init__(self):
        self.settings = get_security_settings()
        self.sqlite_path = None
        self.pg_connection = None
        
    def setup_connections(self, sqlite_path: str):
        """Setup both database connections"""
        try:
            # SQLite connection
            if not os.path.exists(sqlite_path):
                raise FileNotFoundError(f"SQLite database not found: {sqlite_path}")
            self.sqlite_path = sqlite_path
            
            # PostgreSQL connection
            self.pg_connection = psycopg2.connect(self.settings.DATABASE_URL)
            
            logger.info("Database connections established")
            return True
        except Exception as e:
            logger.error(f"Connection setup failed: {e}")
            return False
    
    def get_tables(self):
        """Get list of tables from SQLite"""
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()
        return tables
    
    def migrate_table(self, table_name: str):
        """Migrate a single table"""
        try:
            # Get data from SQLite
            sqlite_conn = sqlite3.connect(self.sqlite_path)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute(f"SELECT * FROM {table_name}")
            rows = sqlite_cursor.fetchall()
            
            if not rows:
                logger.info(f"Table {table_name} is empty")
                sqlite_conn.close()
                return True
            
            # Get column info
            sqlite_cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [col[1] for col in sqlite_cursor.fetchall()]
            
            # Insert into PostgreSQL
            pg_cursor = self.pg_connection.cursor()
            
            # Clear existing data
            pg_cursor.execute(f"DELETE FROM {table_name}")
            
            # Insert new data
            placeholders = ', '.join(['%s'] * len(columns))
            insert_sql = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders})"
            
            pg_cursor.executemany(insert_sql, rows)
            self.pg_connection.commit()
            
            sqlite_conn.close()
            logger.info(f"Migrated {len(rows)} rows from {table_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to migrate {table_name}: {e}")
            self.pg_connection.rollback()
            return False
    
    def run_migration(self, sqlite_path: str):
        """Run complete migration"""
        try:
            logger.info("Starting database migration")
            
            if not self.setup_connections(sqlite_path):
                return False
            
            tables = self.get_tables()
            logger.info(f"Found {len(tables)} tables: {tables}")
            
            successful = 0
            for table_name in tables:
                if self.migrate_table(table_name):
                    successful += 1
            
            logger.info(f"Migration completed: {successful}/{len(tables)} tables successful")
            return successful == len(tables)
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            return False
        finally:
            if self.pg_connection:
                self.pg_connection.close()

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Migrate Izishop database')
    parser.add_argument('--sqlite-path', required=True, help='Path to SQLite database')
    
    args = parser.parse_args()
    
    migrator = DatabaseMigrator()
    success = migrator.run_migration(args.sqlite_path)
    
    if success:
        logger.info("Migration completed successfully!")
        sys.exit(0)
    else:
        logger.error("Migration failed!")
        sys.exit(1)

if __name__ == "__main__":
    main() 