import requests
import json
import time

# Wait for server
time.sleep(2)

# Login
login_response = requests.post('http://127.0.0.1:8000/api/auth/login', json={
    'email': 'pitury@mailinator.com',
    'password': 'Pa$$w0rd!'
})

if login_response.status_code != 200:
    print('Login failed:', login_response.text)
    exit(1)

token = login_response.json()['access_token']

# Get orders
headers = {'Authorization': f'Bearer {token}'}
orders_response = requests.get('http://127.0.0.1:8000/api/orders-v2/customer/orders?limit=10&page=1', headers=headers)

if orders_response.status_code == 200:
    orders_data = orders_response.json()
    print(f'SUCCESS - Total orders: {len(orders_data["orders"])}')
    print()

    # Display each order
    for order in orders_data['orders']:
        print(f'Order {order["order_id"][:8]}... - Shop: {order["shop_name"]}')
        for item in order['items']:
            has_img = 'YES' if item.get('product_image') else 'NO'
            print(f'  Type: {item["product_type"]:7} | {item["product_name"][:40]:40} | Img: {has_img}')
        print()
else:
    print(f'ERROR {orders_response.status_code}')
    print(orders_response.text[:500])
