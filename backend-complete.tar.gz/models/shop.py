import uuid
from datetime import datetime
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Text, Float, Integer
from sqlalchemy.orm import relationship
from database.base import Base

class Shop(Base):
    __tablename__ = "shops"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True)
    owner_id = Column(String, ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    address = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    email = Column(String, nullable=True)
    profile_photo = Column(String, nullable=True)  # URL/path to profile photo
    background_image = Column(String, nullable=True)  # URL/path to background image
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    average_rating = Column(Float, default=0.0)
    total_reviews = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # About section fields
    mission = Column(Text, nullable=True)
    vision = Column(Text, nullable=True)
    website = Column(String, nullable=True)
    business_hours = Column(Text, nullable=True)  # JSON string for business hours
    policies = Column(Text, nullable=True)  # JSON string for policies
    team_members = Column(Text, nullable=True)  # JSON string for team members
    milestones = Column(Text, nullable=True)  # JSON string for milestones
    certifications = Column(Text, nullable=True)  # JSON string for certifications
    coordinates = Column(Text, nullable=True)  # JSON string for lat/lng
    followers_count = Column(Integer, default=0)
    product_count = Column(Integer, default=0)
    total_sales = Column(Float, default=0.0)

    # Relationships
    owner = relationship("User", back_populates="shop")
    analytics_metrics = relationship("AnalyticsMetric", back_populates="shop")
    reviews = relationship("Review", back_populates="shop", cascade="all, delete-orphan")
    # ratings = relationship("Rating", back_populates="shop")
    # stats = relationship("ShopStats", uselist=False, back_populates="shop")
    # orders = relationship("Order", back_populates="shop") 